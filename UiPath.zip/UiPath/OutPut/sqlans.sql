-- Create a table
CREATE TABLE employees (
    id INT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    department VARCHAR(100)
);

-- Insert some data
INSERT INTO employees (id, name, age, department) VALUES (1, 'John Doe', 30, 'Engineering');

-- Query the data
SELECT * FROM employees;
